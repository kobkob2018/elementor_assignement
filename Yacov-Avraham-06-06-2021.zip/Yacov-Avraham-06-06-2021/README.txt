Welcome to my home assignment!
to make everything work:

upload the content of "project" folder to a php server and 

browse to the uploaded folder url (or to the index.html).

then you should see the 3 product boxes, as requested.

--- 

you can also open the index.html file localy, and 

everything should work, exept the part of fatching data from the server

---

I recomend buying the shue ;)



Thankyou, and I hope you enjoy!
Yacov Avraham